# KI-Monitoring — Einrichtung

Tägliches, automatisiertes Briefing zu Copilot, EU AI Act, Data Governance und KI-Releases via Claude Code Routine.

## Repo-Struktur

```
ki-monitoring/
├── README.md            # Diese Anleitung
├── ROUTINE-PROMPT.md    # Der Prompt für die Routine (Quelle der Wahrheit)
├── quellen.md           # Kuratierte Quellenliste — von dir gepflegt
├── themen-log.md        # Laufende Dossiers — von der Routine gepflegt
└── briefings/
    └── JJJJ-MM-TT.md    # Ein Briefing pro Lauf
```

## Einrichtung (einmalig, ~15 Minuten)

1. **Repo anlegen:** Neues privates GitHub-Repo `ki-monitoring` erstellen und diese Dateien hochladen.
2. **Routine erstellen:** Auf https://claude.ai/code → **Routines** → **New routine** (alternativ in der Claude Code CLI: `/schedule`).
3. **Konfigurieren:**
   - **Prompt:** Inhalt aus `ROUTINE-PROMPT.md` (ab "## Deine Rolle") einfügen.
   - **Repository:** `ki-monitoring` auswählen. Branch-Pushes erlauben, damit die Routine committen kann (Standard: nur `claude/`-Branches — für dieses Repo unrestricted pushes aktivieren oder Briefings via PR mergen).
   - **Tools:** Websuche aktivieren. Alle nicht benötigten Konnektoren entfernen (Prinzip: minimale Rechte).
   - **Trigger:** Schedule → *Weekdays*, z.B. 06:00 Uhr (lokale Zeit). Läufe starten ggf. einige Minuten versetzt.
4. **Optional — Zustellung:** Slack- oder E-Mail-Konnektor hinzufügen und im Prompt ergänzen: "Sende das fertige Briefing zusätzlich an [Kanal/Adresse]."
5. **Testlauf:** Routine einmal manuell auslösen und das erste Briefing prüfen.

## Betrieb

- **Erste Woche:** Briefings kritisch gegenlesen und den Prompt nachschärfen (zu viel Rauschen → Relevanzkategorien präzisieren; falsche Quellen → `quellen.md` anpassen). Die meisten Routinen brauchen 1–2 Iterationen.
- **Limits im Blick:** Pro-Plan = 5 Routine-Läufe/Tag; ein täglicher Lauf ist damit entspannt drin.
- **Kein internes Material:** Die Routine arbeitet ausschließlich mit öffentlichen Quellen. Keine DB-internen Dokumente, Zugangsdaten oder Systeme einbinden.
- **Verifikation bleibt bei dir:** Der Agent belegt jede Aussage mit einer Primärquelle — die finale Prüfung vor interner Weitergabe (v.a. bei Regulatorik) machst du.

## Wartung

| Wann | Was |
|---|---|
| Wöchentlich | `themen-log.md` überfliegen, veraltete Dossiers schließen |
| Monatlich | `quellen.md` aufräumen (tote/unergiebige Quellen raus) |
| Bei Bedarf | Prompt anpassen, wenn sich dein Aufgabenzuschnitt ändert |
